import { useState, useEffect } from 'react'
import { supabase } from '../supabase'
import { useAuth } from '../contexts/AuthContext'

export interface Invitation {
  id: number
  from_uid: string
  from_name: string
  to_uid: string
  status: 'pending' | 'accepted' | 'rejected'
  created_at: string
}

export function useInvitation() {
  const { user } = useAuth()
  const [pendingInvitation, setPendingInvitation] = useState<Invitation | null>(null)
  const [invitationResponse, setInvitationResponse] = useState<'accepted' | 'rejected' | null>(null)

  const getMyName = () => {
    return user?.user_metadata?.display_name || user?.email?.split('@')[0] || '匿名'
  }

  // 轮询检查邀请
  useEffect(() => {
    if (!user) return

    const poll = setInterval(async () => {
      const { data } = await supabase
        .from('invitations')
        .select('*')
        .eq('to_uid', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(1)

      if (data && data.length > 0) {
        setPendingInvitation(data[0] as Invitation)
      } else {
        setPendingInvitation(null)
      }

      // 检查对方是否回应了我的邀请
      const { data: responseData } = await supabase
        .from('invitations')
        .select('*')
        .eq('from_uid', user.id)
        .in('status', ['accepted', 'rejected'])
        .order('created_at', { ascending: false })
        .limit(1)

      if (responseData && responseData.length > 0) {
        const latest = responseData[0]
        setInvitationResponse(latest.status as 'accepted' | 'rejected')
        // 清理
        await supabase.from('invitations').delete().eq('id', latest.id)
        setTimeout(() => setInvitationResponse(null), 3000)
      }
    }, 2000)

    return () => clearInterval(poll)
  }, [user])

  const sendInvitation = async (toUid: string) => {
    if (!user) return
    await supabase.from('invitations').insert({
      from_uid: user.id,
      from_name: getMyName(),
      to_uid: toUid,
      status: 'pending'
    })
  }

  const acceptInvitation = async () => {
    if (!user || !pendingInvitation) return
    await supabase
      .from('invitations')
      .update({ status: 'accepted' })
      .eq('id', pendingInvitation.id)
    setPendingInvitation(null)
  }

  const rejectInvitation = async () => {
    if (!user || !pendingInvitation) return
    await supabase
      .from('invitations')
      .update({ status: 'rejected' })
      .eq('id', pendingInvitation.id)
    setPendingInvitation(null)
  }

  return { pendingInvitation, invitationResponse, sendInvitation, acceptInvitation, rejectInvitation }
}
